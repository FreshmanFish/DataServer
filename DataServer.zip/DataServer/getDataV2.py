from logging import DEBUG

import pymysql
import psutil
import socket
import time
import yaml
import logging
from logging.handlers import RotatingFileHandler


def get_cpu_percent():
    cpu_load = psutil.cpu_percent(interval=1)
    return cpu_load


def get_mem_detail():
    mem_percent = psutil.virtual_memory().percent
    mem_used = psutil.virtual_memory().used / 1024 / 1024 / 1024
    return mem_percent, mem_used


def get_disk_detail():
    disk_info = psutil.disk_partitions()
    details = []
    for disk in disk_info:
        disk_percent = psutil.disk_usage(disk.device).percent
        disk_used = psutil.disk_usage(disk.device).used / 1024 / 1024 / 1024
        details.append((disk_percent, disk_used))
    disk_information_len = len(details)
    if disk_information_len == 1:
        c_percent, c_used = details[0][0], details[0][1]
        d_percent, d_used = 0, 0
        e_percent, e_used = 0, 0
        f_percent, f_used = 0, 0
        info = [c_percent, c_used, d_percent, d_used, e_percent, e_used, f_percent, f_used]
        return info
    elif disk_information_len == 2:
        c_percent, c_used = details[0][0], details[0][1]
        d_percent, d_used = details[1][0], details[1][1]
        e_percent, e_used = 0, 0
        f_percent, f_used = 0, 0
        info = [c_percent, c_used, d_percent, d_used, e_percent, e_used, f_percent, f_used]
        return info
    elif disk_information_len == 3:
        c_percent, c_used = details[0][0], details[0][1]
        d_percent, d_used = details[1][0], details[1][1]
        e_percent, e_used = details[2][0], details[2][1]
        f_percent, f_used = 0, 0
        info = [c_percent, c_used, d_percent, d_used, e_percent, e_used, f_percent, f_used]
        return info
    else:
        c_percent, c_used = details[0][0], details[0][1]
        d_percent, d_used = details[1][0], details[1][1]
        e_percent, e_used = details[2][0], details[2][1]
        f_percent, f_used = details[3][0], details[3][1]
        info = [c_percent, c_used, d_percent, d_used, e_percent, e_used, f_percent, f_used]
        return info


def get_server_ip_host():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        with open('server.yaml', 'r', encoding='utf8') as f:
            file = yaml.safe_load(f)
            gateway_addr = file['gateway']['ip']
            s.connect((f'{gateway_addr}', 0))
            ipaddr = s.getsockname()[0]
            server_name = file['server'][ipaddr]
        return ipaddr, server_name
    except:
        logs.error("配置文件中未找到IP地址及服务器名称")


def connect_mysql_database():
    try:
        with open('dataSource.yaml', 'r', encoding='utf8') as f:
            file = yaml.safe_load(f)
            host = file['dataSource']['host']
            port = file['dataSource']['port']
            user = file['dataSource']['user']
            passwd = file['dataSource']['passwd']
            db = file['dataSource']['db']
            conn = pymysql.connect(host=host, port=port, user=user, password=passwd, database=db)
            return conn
    except:
        logs.error("连接数据库出错")


def get_logs():
    logger = logging.getLogger('myLogger')
    logger.setLevel(logging.DEBUG)
    handler = RotatingFileHandler('all.log', encoding='utf8', maxBytes=5 * 1024 * 1024, backupCount=10)
    formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    return logger


if __name__ == '__main__':
    logs = get_logs()

    optime = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime())

    disk_information = get_disk_detail()
    serverName = get_server_ip_host()[1]
    ipaddress = get_server_ip_host()[0]
    cpuPercent = get_cpu_percent()
    memoryPercent = get_mem_detail()[0]
    memoryUsed = get_mem_detail()[1]

    my_sql = f'''insert into systeminfo(serverName, serverIP, CPU_percent, Mem_percent, Mem_data, Disk_C_percent, 
        Disk_C_data, Disk_D_percent, Disk_D_data, Disk_E_percent, Disk_E_data, Disk_F_percent, Disk_F_data, Optime)
         value ("{serverName}","{ipaddress}",{cpuPercent},{memoryPercent},{memoryUsed},
        {disk_information[0]},{disk_information[1]},{disk_information[2]},{disk_information[3]},{disk_information[4]},
        {disk_information[5]},{disk_information[6]},{disk_information[7]},"{optime}")'''
    connection = connect_mysql_database()
    cur = connection.cursor()
    cur.execute(my_sql)
    connection.commit()
    connection.close()
    logs.info('数据插入成功')
