-- server.systeminfo definition

CREATE TABLE `systeminfo` (
  `id` int NOT NULL AUTO_INCREMENT COMMENT '序号',
  `serverName` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '服务器' COMMENT '服务器名称',
  `serverIP` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '127.0.0.1' COMMENT '服务器IP地址',
  `CPU_percent` float NOT NULL DEFAULT '0' COMMENT 'CPU使用率',
  `Mem_percent` float NOT NULL DEFAULT '0' COMMENT '内存使用率',
  `Mem_data` float NOT NULL DEFAULT '0' COMMENT '内存使用量',
  `Disk_C_percent` float NOT NULL DEFAULT '0' COMMENT 'C盘使用率',
  `Disk_C_data` float NOT NULL DEFAULT '0' COMMENT 'C盘使用量',
  `Disk_D_percent` float DEFAULT '0' COMMENT 'D盘使用率',
  `Disk_D_data` float DEFAULT '0' COMMENT 'D盘使用量',
  `Disk_E_percent` float DEFAULT '0' COMMENT 'E盘使用率',
  `Disk_E_data` float DEFAULT '0' COMMENT 'E盘使用量',
  `Disk_F_percent` float DEFAULT '0' COMMENT 'F盘使用率',
  `Disk_F_data` float DEFAULT '0' COMMENT 'F盘使用量',
  `Optime` datetime DEFAULT NULL COMMENT '记录写入数据库时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='服务器CPU使用率、内存使用率、磁盘空间使用率信息';